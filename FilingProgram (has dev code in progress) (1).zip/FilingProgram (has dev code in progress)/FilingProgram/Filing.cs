﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace FilingProgram
{
    class Filing
    {
        private string project_name; 
        
        public Filing() { project_name = ""; }
        public Filing(string prjName)
        { 
            project_name = prjName;              
        }
            
        public string GETSETprj_name {
            get { return project_name; }
            set { project_name = value; }
        }

        public static bool Matches(string input, string pattern) {
            return Regex.IsMatch(input, pattern);
        }

        public string[] return_PrjNames() {
            string[] storePrjNames = new string[] { "Project Control", "Civil Engineering", 
                                                    "EcologicaURegulatory","Ecological/Regulatory", "Landscape", "Planning",
                                                    "GIS","Structural","Surveying","Traffic","Survey Root Directory" };   
            return storePrjNames;
        }

        public string[] return_PrjLocation() {
            string[] prjLocation = new string[] { "Boston", "Worcester - 0", "Worcester - 0", "Glastonbury", "West Yarmouth" };
            return prjLocation;
        }

        //if true, method will be used to warn user.
        public bool DirectoryExists(string location,string projectNum,string stuff) {
            if (location == "Boston")
                return Directory.Exists(getUNCpath("Boston", projectNum, stuff));
            else if (location == "Worcester - 0")                                           
                return Directory.Exists(getUNCpath("Worcester - 0", projectNum, stuff));
            else if (location == "Worcester - 1")
                return Directory.Exists(getUNCpath("Worcester - 1", projectNum, stuff));
            else if (location == "Glastonbury")
                return Directory.Exists(getUNCpath("Glastonbury", projectNum, stuff));
            else if (location == "West Yarmouth")
                return Directory.Exists(getUNCpath("West Yarmouth", projectNum, stuff));
            else
                return false; //if false initialize the process.
        }

        public string PhotoPath(string network_path, string prj_num) {
            if (network_path == "Boston")
                return @"\\virgo\pictures\" + prj_num;
            else if (network_path == "Worcester - 0" || network_path == "Worcester - 1")
                return @"\\norma\pictures\" + prj_num;
            else if (network_path == "Glastonbury")
                return @"\\gzen1\pictures\" + prj_num;
            else if (network_path == "West Yarmouth")
                return @"\\yzen1\pictures\" + prj_num;

            return "";
        }

        public string getUNCpath(string network_path, string prj_num, string stuff)
        {
            if (network_path == "Boston")
                return @"\\aries\prj0\prj\" + prj_num + "\\" + stuff;
            else if (network_path == "Worcester - 0")
                return @"\\wor-data\prj0\" + prj_num + "\\" + stuff;
            else if (network_path == "Worcester - 1")
                return @"\\wor-data\prj1\" + prj_num + "\\" + stuff;
            else if (network_path == "Glastonbury")
                return @"\\lynx\prj0\prj\" + prj_num + "\\" + stuff;
            else if (network_path == "West Yarmouth")
                return @"\\dorado\prj0\prj\" + prj_num + "\\" + stuff;

            return "";
        }

        public string getUNCpath(string network_path,string prj_num) {
            if (network_path == "Boston")
                return @"\\aries\prj0\prj\" + prj_num;
            else if (network_path == "Worcester - 0")
                return @"\\wor-data\prj0\" + prj_num;
            else if (network_path == "Worcester - 1")
                return @"\\wor-data\prj1\" + prj_num;
            else if (network_path == "Glastonbury")
                return @"\\lynx\prj0\prj\" + prj_num;
            else if (network_path == "West Yarmouth")
                return @"\\dorado\prj0\prj\" + prj_num;

            return "";
        }

        public void getDirectoryInfo(DirectoryInfo theSource, DirectoryInfo theDest, string where,           
                                     Filing theProject,string dataDIR) {
        
            Directory.CreateDirectory(theProject.getUNCpath(where, theProject.GETSETprj_name));
            Directory.CreateDirectory(theProject.getUNCpath(where, theProject.GETSETprj_name) + "\\" + dataDIR);

            Filing.CopyFilesRecursively(theSource, theDest);
        }

        public static void CopyFilesRecursively(DirectoryInfo source, DirectoryInfo target)
        {
            foreach (DirectoryInfo dir in source.GetDirectories())
                CopyFilesRecursively(dir, target.CreateSubdirectory(dir.Name));
            foreach (FileInfo file in source.GetFiles())
                file.CopyTo(Path.Combine(target.FullName, file.Name));          
        }
    }
}
