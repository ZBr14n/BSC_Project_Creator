﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using Word = Microsoft.Office.Interop.Word;
using Microsoft.Office.Interop.Word;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.pdf.parser;
using System.Text.RegularExpressions;

namespace FilingProgram
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();              
        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
          
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
            
        private void button1_Click(object sender, EventArgs e)
        {
            Filing theProject = new Filing(proj_num.Text);
         
            string[] storeDataLoc = new string[] { ProjectControl.Text, CivilEngineering.Text, Enviro.Text,GIS.Text,HazMaterials.Text,
                                                   Landscape.Text,Planning.Text,Structural.Text,Survey.Text,Transportation.Text,zForGIS.Text,
                                                   zForSurveyRoot.Text };

            string[] storeLABELS = new string[] { prj_LABEL1.Text, civil_LABEL2.Text, enviro_LABEL3.Text,GIS_LABEL4.Text,haza_LABEL5.Text,
                                                  land_LABEL6.Text,plan_LABEL7.Text,struct_LABEL8.Text,survey_LABEL9.Text,trans_LABEL10.Text,
                                                  zGIS_LABEL11.Text,zRootSurvey_LABEL12.Text };
            
            DialogResult ans = MessageBox.Show("Are you sure you want to continue?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                            
            if (proj_num.Text == "")
            {
                MessageBox.Show("The field is empty. Please enter the Project Number.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {           
                for (int i = 0, j = 0; i < storeDataLoc.Length && j < storeLABELS.Length; i++, j++)
                {
                    if (theProject.DirectoryExists(storeDataLoc[i], theProject.GETSETprj_name, storeLABELS[j]) == true)
                    {
                        MessageBox.Show("There is already an existing directory; unable to add the same Project folder(s) to the directory. However, there are new Project folder(s) that have been added to the directory. No files or folders have been deleted or overwritten.",
                                        "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        break;
                    }
                }

                if (ans == DialogResult.Yes)
                {
                    for (int i = 0, j = 0; i < storeDataLoc.Length && j < storeLABELS.Length; i++, j++)
                    {                        
                            switch (storeDataLoc[i])
                            {
                                case "Boston":
                                    DirectoryInfo theSource = new DirectoryInfo(@"X:\appl\Projects\" + storeLABELS[j]);
                                    DirectoryInfo theDest = new DirectoryInfo(@"\\aries\PRJ0\Prj\" + theProject.GETSETprj_name + "\\" + storeLABELS[j]);
                                    theProject.getDirectoryInfo(theSource, theDest, "Boston", theProject, storeLABELS[j]);

                                    Directory.CreateDirectory(theProject.PhotoPath("Boston", theProject.GETSETprj_name));
                                    Directory.CreateDirectory(theProject.PhotoPath("Boston", theProject.GETSETprj_name) + "\\" + "Photos");
                                    break;

                                case "Worcester - 0":
                                    DirectoryInfo theSource2 = new DirectoryInfo(@"X:\appl\Projects\" + storeLABELS[j]);
                                    DirectoryInfo theDest2 = new DirectoryInfo(@"\\wor-data\PRJ0\" + theProject.GETSETprj_name + "\\" + storeLABELS[j]);
                                    theProject.getDirectoryInfo(theSource2, theDest2, "Worcester - 0", theProject, storeLABELS[j]);

                                    Directory.CreateDirectory(theProject.PhotoPath("Worcester - 0", theProject.GETSETprj_name));
                                    Directory.CreateDirectory(theProject.PhotoPath("Worcester - 0", theProject.GETSETprj_name) + "\\" + "Photos");
                                    break;

                                case "Worcester - 1":
                                    DirectoryInfo theSource3 = new DirectoryInfo(@"X:\appl\Projects\" + storeLABELS[j]);
                                    DirectoryInfo theDest3 = new DirectoryInfo(@"\\wor-data\PRJ1\" + theProject.GETSETprj_name + "\\" + storeLABELS[j]);
                                    theProject.getDirectoryInfo(theSource3, theDest3, "Worcester - 1", theProject, storeLABELS[j]);

                                    Directory.CreateDirectory(theProject.PhotoPath("Worcester - 1", theProject.GETSETprj_name));
                                    Directory.CreateDirectory(theProject.PhotoPath("Worcester - 1", theProject.GETSETprj_name) + "\\" + "Photos");
                                    break;

                                case "Glastonbury":
                                    DirectoryInfo theSource4 = new DirectoryInfo(@"X:\appl\Projects\" + storeLABELS[j]);
                                    DirectoryInfo theDest4 = new DirectoryInfo(@"\\lynx\PRJ0\Prj\" + theProject.GETSETprj_name + "\\" + storeLABELS[j]);
                                    theProject.getDirectoryInfo(theSource4, theDest4, "Glastonbury", theProject, storeLABELS[j]);

                                    Directory.CreateDirectory(theProject.PhotoPath("Glastonbury", theProject.GETSETprj_name));
                                    Directory.CreateDirectory(theProject.PhotoPath("Glastonbury", theProject.GETSETprj_name) + "\\" + "Photos");
                                    break;

                                case "West Yarmouth":
                                    DirectoryInfo theSource5 = new DirectoryInfo(@"X:\appl\Projects\" + storeLABELS[j]);
                                    DirectoryInfo theDest5 = new DirectoryInfo(@"\\dorado\PRJ0\Prj\" + theProject.GETSETprj_name + "\\" + storeLABELS[j]);
                                    theProject.getDirectoryInfo(theSource5, theDest5, "West Yarmouth", theProject, storeLABELS[j]);

                                    Directory.CreateDirectory(theProject.PhotoPath("West Yarmouth", theProject.GETSETprj_name));
                                    Directory.CreateDirectory(theProject.PhotoPath("West Yarmouth", theProject.GETSETprj_name) + "\\" + "Photos");
                                    break;
                            }                                                                          
                    }

                    IEnumerable<string> distinctDataLoc = storeDataLoc.Distinct();

                    foreach (string distinctLocations in distinctDataLoc)
                    {
                        if (distinctLocations != "")
                        {
                            switch (distinctLocations)
                            {
                                case "Boston":
                                    Process.Start("explorer.exe", @"/select,\\aries\prj0\prj\" + theProject.GETSETprj_name);
                                    break;
                                case "Worcester - 0":
                                    Process.Start("explorer.exe", @"/select,\\wor-data\prj0\" + theProject.GETSETprj_name);
                                    break;
                                case "Worcester - 1":
                                    Process.Start("explorer.exe", @"/select,\\wor-data\prj1\" + theProject.GETSETprj_name);
                                    break;
                                case "Glastonbury":
                                    Process.Start("explorer.exe", @"/select,\\lynx\prj0\prj\" + theProject.GETSETprj_name);
                                    break;
                                case "West Yarmouth":
                                    Process.Start("explorer.exe", @"/select,\\dorado\prj0\prj\" + theProject.GETSETprj_name);
                                    break;
                            }
                        }
                    }
                }
                else { }
            }
        }
    
        private void switchToToolStripMenuItem_Click(object sender, EventArgs e)
        {
     
        }

        private void switchToToolStripMenuItem1_Click(object sender, EventArgs e)
        {
                   
        }

        private void browse_Click(object sender, EventArgs e)
        {
        }

        private void proj_num_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
             
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void menuStrip2_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void switchToToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            //panel1.Visible = true;
        }

        private void switchToToolStripMenuItem1_Click_1(object sender, EventArgs e)
        {
            //panel1.Visible = false;
        }

        private void panel1_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.ShowDialog();
        }


        //Credits go to Cathal Coffey for helping me with Microsoft.Office.Interop.Word, which i need to use to convert to pdf.
        public static void ConvertToPDF(string input, string output, WdSaveFormat format)
        {
            Word._Application oWord = new Word.Application();
 
            // Make this instance of word invisible (Can still see it in the taskmgr).
            oWord.Visible = false;
 
            // Interop requires objects.
            object oMissing = System.Reflection.Missing.Value;
            object isVisible = true;
            object readOnly = false;
            object oInput = input;
            object oOutput = output;
            object oFormat = format;
 
            //Load doc into Word
            Word._Document oDoc = oWord.Documents.Open(ref oInput, ref oMissing, ref readOnly, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref isVisible, ref oMissing, ref oMissing, ref oMissing, ref oMissing);
 
            //active document.
            oDoc.Activate();
 
            //Save doc
            oDoc.SaveAs(ref oOutput, ref oFormat, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing);
            
            //close Word.exe.
            oWord.Quit(ref oMissing, ref oMissing, ref oMissing);

            //finds winword on taskmanager and ends the process.
            foreach (Process proc in Process.GetProcessesByName("winword"))
            {
                if (!proc.HasExited)
                {
                    proc.Kill();
                }
            }
        }

        private void browse_Click_1(object sender, EventArgs e)
        {
            Form4 form4 = new Form4();
            OpenFileDialog ofd = new OpenFileDialog();
            Filing theProject = new Filing(proj_num.Text);
            ofd.Filter = "PDF Files (*.pdf)|*.pdf|Word Doc (*.docx)|*.docx";    //only .docx and pdf are allowed to be inserted.

            if (ofd.ShowDialog() == DialogResult.OK)        //opens file dialog and shows the path and filename
                FilePathName.Text = ofd.FileName.ToString();

            string DOCX_FilePathName = "";
            string newPath = "";
            if (FilePathName.Text.Contains(".docx"))        //if the input file is .docx , convert to pdf.
            {
                newPath = FilePathName.Text.Replace(".docx"," (new copy).pdf");
                ConvertToPDF(FilePathName.Text, newPath, WdSaveFormat.wdFormatPDF);
                DOCX_FilePathName = newPath;
            }

            try
            {
                PdfReader read;
                if (FilePathName.Text.Contains(".docx"))
                {
                    read = new PdfReader(DOCX_FilePathName);
                }
                else
                {
                    read = new PdfReader(FilePathName.Text);
                }

                string tempSTR = "";
                for (int pg = 1; pg <= 1; pg++)
                {
                    ITextExtractionStrategy ITS = new iTextSharp.text.pdf.parser.LocationTextExtractionStrategy();
                    string str = PdfTextExtractor.GetTextFromPage(read, pg, ITS);
                    str = Encoding.UTF8.GetString(ASCIIEncoding.Convert(Encoding.Default, Encoding.UTF8, Encoding.Default.GetBytes(str)));
                    tempSTR += str;
                }

                string hold_substr = tempSTR.Substring(0, 300);
                string hold_capturedValue = "";
                if (Filing.Matches(hold_substr,@"Project Number ([0-9]) \d+ \d+"))
                {              
                    MatchCollection matchSUBSTR = Regex.Matches(hold_substr, @"Project Number ([0-9]) \d+ \d+");
                    foreach (Match match in matchSUBSTR)
                    {
                        if (match.Success)
                        {
                            foreach (Capture capture in match.Captures) { hold_capturedValue = Convert.ToString(capture.Value); }
                        }
                    }
                    hold_capturedValue = hold_capturedValue.Replace("Project Number", "");
                    hold_capturedValue = hold_capturedValue.Replace(" ", "");
                    proj_num.Text = hold_capturedValue;
                }
                else if (Filing.Matches(hold_substr, @"\d+ \d+")) {
                    MatchCollection matchSUBSTR = Regex.Matches(hold_substr, @"\d+ \d+");
                    foreach (Match match in matchSUBSTR)
                    {
                        if (match.Success)
                        {
                            foreach (Capture capture in match.Captures) { hold_capturedValue = Convert.ToString(capture.Value); }
                        }
                    }
                    proj_num.Text = hold_capturedValue;
                }
                else
                {
                    MatchCollection matchSUBSTR2 = Regex.Matches(hold_substr, @"^(.+)$", RegexOptions.Multiline);
                    foreach (Match match2 in matchSUBSTR2)
                    {
                        if (match2.Success)
                        {
                            foreach (Capture capture in match2.Captures) { hold_capturedValue = Convert.ToString(capture.Value); }
                        }
                    }
                    hold_capturedValue = hold_capturedValue.Substring(hold_capturedValue.IndexOf("Project Number"));
                    hold_capturedValue = hold_capturedValue.Replace(".", "");
                    hold_capturedValue = hold_capturedValue.Replace("Project Number", "");
                    hold_capturedValue = hold_capturedValue.Replace(" ", "");
                    proj_num.Text = hold_capturedValue;
                }

                for(int j=0; j < theProject.return_PrjLocation().Length;j++)
                {
                    MatchCollection matches2 = Regex.Matches(tempSTR,theProject.return_PrjLocation()[j]);                          
                    foreach (Match match in matches2)
                    {
                        foreach (Capture capture in match.Captures)
                        {
                            for (int i = 0; i < theProject.return_PrjNames().Length; i++)
                            {
                                switch (theProject.return_PrjNames()[i])
                                {
                                    case "Project Control":
                                        if (Filing.Matches(tempSTR, theProject.return_PrjNames()[i] + " " + Convert.ToString(capture.Value)))
                                        {
                                            switch (Convert.ToString(capture.Value))
                                            {
                                                case "Boston":
                                                    ProjectControl.Text = "Boston"; break;
                                                case "Worcester - 0":
                                                    ProjectControl.Text = "Worcester - 0"; break;
                                                case "Worcester - 1":
                                                    ProjectControl.Text = "Worcester - 1"; break;
                                                case "West Yarmouth":
                                                    ProjectControl.Text = "West Yarmouth"; break;
                                                case "Glastonbury":
                                                    ProjectControl.Text = "Glastonbury"; break;
                                            }
                                        }
                                        break;
                                    case "Civil Engineering":
                                        if (Filing.Matches(tempSTR, theProject.return_PrjNames()[i] + " " + Convert.ToString(capture.Value)))
                                        {
                                            switch (Convert.ToString(capture.Value))
                                            {
                                                case "Boston":
                                                    CivilEngineering.Text = "Boston"; break;
                                                case "Worcester - 0":
                                                    CivilEngineering.Text = "Worcester - 0"; break;
                                                case "Worcester - 1":
                                                    CivilEngineering.Text = "Worcester - 1"; break;
                                                case "West Yarmouth":
                                                    CivilEngineering.Text = "West Yarmouth"; break;
                                                case "Glastonbury":
                                                    CivilEngineering.Text = "Glastonbury"; break;
                                            }
                                        }
                                        break;
                                    case "Ecological/Regulatory":
                                    case "EcologicalURegulatory":
                                        if (Filing.Matches(tempSTR, theProject.return_PrjNames()[i] + " " + Convert.ToString(capture.Value)))
                                        {
                                            switch (Convert.ToString(capture.Value))
                                            {
                                                case "Boston":
                                                    Enviro.Text = "Boston"; break;
                                                case "Worcester - 0":
                                                    Enviro.Text = "Worcester - 0"; break;
                                                case "Worcester - 1":
                                                    Enviro.Text = "Worcester - 1"; break;
                                                case "West Yarmouth":
                                                    Enviro.Text = "West Yarmouth"; break;
                                                case "Glastonbury":
                                                    Enviro.Text = "Glastonbury"; break;
                                            }
                                        }
                                        break;
                                    case "GIS":
                                        if (Filing.Matches(tempSTR, theProject.return_PrjNames()[i] + " " + Convert.ToString(capture.Value)))
                                        {
                                            switch (Convert.ToString(capture.Value))
                                            {
                                                case "Boston":
                                                    GIS.Text = "Boston"; break;
                                                case "Worcester - 0":
                                                    GIS.Text = "Worcester - 0"; break;
                                                case "Worcester - 1":
                                                    GIS.Text = "Worcester - 1"; break;
                                                case "West Yarmouth":
                                                    GIS.Text = "West Yarmouth"; break;
                                                case "Glastonbury":
                                                    GIS.Text = "Glastonbury"; break;
                                            }
                                        }
                                        break;
                                    case "Landscape":
                                        if (Filing.Matches(tempSTR, theProject.return_PrjNames()[i] + " " + Convert.ToString(capture.Value)))
                                        {
                                            switch (Convert.ToString(capture.Value))
                                            {
                                                case "Boston":
                                                    Landscape.Text = "Boston"; break;
                                                case "Worcester - 0":
                                                    Landscape.Text = "Worcester - 0"; break;
                                                case "Worcester - 1":
                                                    Landscape.Text = "Worcester - 1"; break;
                                                case "West Yarmouth":
                                                    Landscape.Text = "West Yarmouth"; break;
                                                case "Glastonbury":
                                                    Landscape.Text = "Glastonbury"; break;
                                            }
                                        }
                                        break;
                                    case "Planning":
                                        if (Filing.Matches(tempSTR, theProject.return_PrjNames()[i] + " " + Convert.ToString(capture.Value)))
                                        {
                                            switch (Convert.ToString(capture.Value))
                                            {
                                                case "Boston":
                                                    Planning.Text = "Boston"; break;
                                                case "Worcester - 0":
                                                    Planning.Text = "Worcester - 0"; break;
                                                case "Worcester - 1":
                                                    Planning.Text = "Worcester - 1"; break;
                                                case "West Yarmouth":
                                                    Planning.Text = "West Yarmouth"; break;
                                                case "Glastonbury":
                                                    Planning.Text = "Glastonbury"; break;
                                            }
                                        }
                                        break;
                                    case "Structural":
                                        if (Filing.Matches(tempSTR, theProject.return_PrjNames()[i] + " " + Convert.ToString(capture.Value)))
                                        {
                                            switch (Convert.ToString(capture.Value))
                                            {
                                                case "Boston":
                                                    Structural.Text = "Boston"; break;
                                                case "Worcester - 0":
                                                    Structural.Text = "Worcester - 0"; break;
                                                case "Worcester - 1":
                                                    Structural.Text = "Worcester - 1"; break;
                                                case "West Yarmouth":
                                                    Structural.Text = "West Yarmouth"; break;
                                                case "Glastonbury":
                                                    Structural.Text = "Glastonbury"; break;
                                            }
                                        }
                                        break;
                                    case "Surveying":
                                        if (Filing.Matches(tempSTR, theProject.return_PrjNames()[i] + " " + Convert.ToString(capture.Value)))
                                        {
                                            switch (Convert.ToString(capture.Value))
                                            {
                                                case "Boston":
                                                    Survey.Text = "Boston"; break;
                                                case "Worcester - 0":
                                                    Survey.Text = "Worcester - 0"; break;
                                                case "Worcester - 1":
                                                    Survey.Text = "Worcester - 1"; break;
                                                case "West Yarmouth":
                                                    Survey.Text = "West Yarmouth"; break;
                                                case "Glastonbury":
                                                    Survey.Text = "Glastonbury"; break;
                                            }
                                        }
                                        break;
                                    case "Traffic":
                                        if (Filing.Matches(tempSTR, theProject.return_PrjNames()[i] + " " + Convert.ToString(capture.Value)))
                                        {
                                            switch (Convert.ToString(capture.Value))
                                            {
                                                case "Boston":
                                                    Transportation.Text = "Boston"; break;
                                                case "Worcester - 0":
                                                    Transportation.Text = "Worcester - 0"; break;
                                                case "Worcester - 1":
                                                    Transportation.Text = "Worcester - 1"; break;
                                                case "West Yarmouth":
                                                    Transportation.Text = "West Yarmouth"; break;
                                                case "Glastonbury":
                                                    Transportation.Text = "Glastonbury"; break;
                                            }
                                        }
                                        break;
                                    case "Survey Root Directory":
                                        if (Filing.Matches(tempSTR, theProject.return_PrjNames()[i] + " " + Convert.ToString(capture.Value)))
                                        {
                                            switch (Convert.ToString(capture.Value))
                                            {
                                                case "Boston":
                                                    zForSurveyRoot.Text = "Boston"; break;
                                                case "Worcester - 0":
                                                    zForSurveyRoot.Text = "Worcester - 0"; break;
                                                case "Worcester - 1":
                                                    zForSurveyRoot.Text = "Worcester - 1"; break;
                                                case "West Yarmouth":
                                                    zForSurveyRoot.Text = "West Yarmouth"; break;
                                                case "Glastonbury":
                                                    zForSurveyRoot.Text = "Glastonbury"; break;
                                            }
                                        }
                                        break;
                                }   
                            }   
                        }
                    }   
                }       
             read.Close();
            }
            catch (Exception) { }     
        }
    
        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void clearFieldsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ProjectControl.Text=""; 
            CivilEngineering.Text="";
            Enviro.Text="";
            GIS.Text="";
            HazMaterials.Text="";
            Landscape.Text="";
            Planning.Text="";
            Structural.Text="";
            Survey.Text="";
            Transportation.Text="";
            zForGIS.Text="";
            zForSurveyRoot.Text="";
            
            proj_num.Text = "";
            FilePathName.Text = "";
        }

        private void configurationsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.ShowDialog();
        }
    }
}
