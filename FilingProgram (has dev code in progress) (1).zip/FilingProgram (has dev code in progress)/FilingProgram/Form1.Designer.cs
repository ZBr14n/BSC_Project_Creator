﻿namespace FilingProgram
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.proj_num = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.create_proj = new System.Windows.Forms.Button();
            this.ProjectControl = new System.Windows.Forms.ComboBox();
            this.CivilEngineering = new System.Windows.Forms.ComboBox();
            this.Enviro = new System.Windows.Forms.ComboBox();
            this.prj_LABEL1 = new System.Windows.Forms.Label();
            this.civil_LABEL2 = new System.Windows.Forms.Label();
            this.enviro_LABEL3 = new System.Windows.Forms.Label();
            this.GIS = new System.Windows.Forms.ComboBox();
            this.HazMaterials = new System.Windows.Forms.ComboBox();
            this.Landscape = new System.Windows.Forms.ComboBox();
            this.GIS_LABEL4 = new System.Windows.Forms.Label();
            this.haza_LABEL5 = new System.Windows.Forms.Label();
            this.land_LABEL6 = new System.Windows.Forms.Label();
            this.Planning = new System.Windows.Forms.ComboBox();
            this.Structural = new System.Windows.Forms.ComboBox();
            this.Survey = new System.Windows.Forms.ComboBox();
            this.plan_LABEL7 = new System.Windows.Forms.Label();
            this.struct_LABEL8 = new System.Windows.Forms.Label();
            this.survey_LABEL9 = new System.Windows.Forms.Label();
            this.Transportation = new System.Windows.Forms.ComboBox();
            this.zForGIS = new System.Windows.Forms.ComboBox();
            this.zForSurveyRoot = new System.Windows.Forms.ComboBox();
            this.trans_LABEL10 = new System.Windows.Forms.Label();
            this.zGIS_LABEL11 = new System.Windows.Forms.Label();
            this.zRootSurvey_LABEL12 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clearFieldsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.FilePathName = new System.Windows.Forms.TextBox();
            this.browse = new System.Windows.Forms.Button();
            this.configurationsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog1_FileOk);
            // 
            // proj_num
            // 
            this.proj_num.Location = new System.Drawing.Point(120, 203);
            this.proj_num.Name = "proj_num";
            this.proj_num.Size = new System.Drawing.Size(159, 20);
            this.proj_num.TabIndex = 0;
            this.proj_num.TextChanged += new System.EventHandler(this.proj_num_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 206);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Project Number";
            // 
            // create_proj
            // 
            this.create_proj.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.create_proj.Location = new System.Drawing.Point(309, 203);
            this.create_proj.Name = "create_proj";
            this.create_proj.Size = new System.Drawing.Size(263, 59);
            this.create_proj.TabIndex = 4;
            this.create_proj.Text = "Create Project";
            this.create_proj.UseVisualStyleBackColor = true;
            this.create_proj.Click += new System.EventHandler(this.button1_Click);
            // 
            // ProjectControl
            // 
            this.ProjectControl.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ProjectControl.FormattingEnabled = true;
            this.ProjectControl.Items.AddRange(new object[] {
            "",
            "Boston",
            "Worcester - 0",
            "Worcester - 1",
            "West Yarmouth",
            "Glastonbury"});
            this.ProjectControl.Location = new System.Drawing.Point(158, 34);
            this.ProjectControl.Name = "ProjectControl";
            this.ProjectControl.Size = new System.Drawing.Size(121, 21);
            this.ProjectControl.TabIndex = 12;
            // 
            // CivilEngineering
            // 
            this.CivilEngineering.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CivilEngineering.FormattingEnabled = true;
            this.CivilEngineering.Items.AddRange(new object[] {
            "",
            "Boston",
            "Worcester - 0",
            "Worcester - 1",
            "West Yarmouth",
            "Glastonbury"});
            this.CivilEngineering.Location = new System.Drawing.Point(158, 57);
            this.CivilEngineering.Name = "CivilEngineering";
            this.CivilEngineering.Size = new System.Drawing.Size(121, 21);
            this.CivilEngineering.TabIndex = 13;
            // 
            // Enviro
            // 
            this.Enviro.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Enviro.FormattingEnabled = true;
            this.Enviro.Items.AddRange(new object[] {
            "",
            "Boston",
            "Worcester - 0",
            "Worcester - 1",
            "West Yarmouth",
            "Glastonbury"});
            this.Enviro.Location = new System.Drawing.Point(158, 80);
            this.Enviro.Name = "Enviro";
            this.Enviro.Size = new System.Drawing.Size(121, 21);
            this.Enviro.TabIndex = 14;
            // 
            // prj_LABEL1
            // 
            this.prj_LABEL1.AutoSize = true;
            this.prj_LABEL1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prj_LABEL1.Location = new System.Drawing.Point(13, 39);
            this.prj_LABEL1.Name = "prj_LABEL1";
            this.prj_LABEL1.Size = new System.Drawing.Size(102, 16);
            this.prj_LABEL1.TabIndex = 18;
            this.prj_LABEL1.Text = "_Project Control";
            // 
            // civil_LABEL2
            // 
            this.civil_LABEL2.AutoSize = true;
            this.civil_LABEL2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.civil_LABEL2.Location = new System.Drawing.Point(13, 60);
            this.civil_LABEL2.Name = "civil_LABEL2";
            this.civil_LABEL2.Size = new System.Drawing.Size(33, 16);
            this.civil_LABEL2.TabIndex = 19;
            this.civil_LABEL2.Text = "Civil";
            // 
            // enviro_LABEL3
            // 
            this.enviro_LABEL3.AutoSize = true;
            this.enviro_LABEL3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.enviro_LABEL3.Location = new System.Drawing.Point(13, 83);
            this.enviro_LABEL3.Name = "enviro_LABEL3";
            this.enviro_LABEL3.Size = new System.Drawing.Size(93, 16);
            this.enviro_LABEL3.TabIndex = 20;
            this.enviro_LABEL3.Text = "Environmental";
            // 
            // GIS
            // 
            this.GIS.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.GIS.FormattingEnabled = true;
            this.GIS.Items.AddRange(new object[] {
            "",
            "Boston",
            "Worcester - 0",
            "Worcester - 1",
            "West Yarmouth",
            "Glastonbury"});
            this.GIS.Location = new System.Drawing.Point(451, 34);
            this.GIS.Name = "GIS";
            this.GIS.Size = new System.Drawing.Size(121, 21);
            this.GIS.TabIndex = 21;
            // 
            // HazMaterials
            // 
            this.HazMaterials.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.HazMaterials.FormattingEnabled = true;
            this.HazMaterials.Items.AddRange(new object[] {
            "",
            "Boston",
            "Worcester - 0",
            "Worcester - 1",
            "West Yarmouth",
            "Glastonbury"});
            this.HazMaterials.Location = new System.Drawing.Point(451, 57);
            this.HazMaterials.Name = "HazMaterials";
            this.HazMaterials.Size = new System.Drawing.Size(121, 21);
            this.HazMaterials.TabIndex = 22;
            // 
            // Landscape
            // 
            this.Landscape.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Landscape.FormattingEnabled = true;
            this.Landscape.Items.AddRange(new object[] {
            "",
            "Boston",
            "Worcester - 0",
            "Worcester - 1",
            "West Yarmouth",
            "Glastonbury"});
            this.Landscape.Location = new System.Drawing.Point(451, 80);
            this.Landscape.Name = "Landscape";
            this.Landscape.Size = new System.Drawing.Size(121, 21);
            this.Landscape.TabIndex = 23;
            // 
            // GIS_LABEL4
            // 
            this.GIS_LABEL4.AutoSize = true;
            this.GIS_LABEL4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GIS_LABEL4.Location = new System.Drawing.Point(306, 39);
            this.GIS_LABEL4.Name = "GIS_LABEL4";
            this.GIS_LABEL4.Size = new System.Drawing.Size(30, 16);
            this.GIS_LABEL4.TabIndex = 24;
            this.GIS_LABEL4.Text = "GIS";
            // 
            // haza_LABEL5
            // 
            this.haza_LABEL5.AutoSize = true;
            this.haza_LABEL5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.haza_LABEL5.Location = new System.Drawing.Point(306, 60);
            this.haza_LABEL5.Name = "haza_LABEL5";
            this.haza_LABEL5.Size = new System.Drawing.Size(132, 16);
            this.haza_LABEL5.TabIndex = 25;
            this.haza_LABEL5.Text = "Hazardous Materials";
            // 
            // land_LABEL6
            // 
            this.land_LABEL6.AutoSize = true;
            this.land_LABEL6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.land_LABEL6.Location = new System.Drawing.Point(306, 83);
            this.land_LABEL6.Name = "land_LABEL6";
            this.land_LABEL6.Size = new System.Drawing.Size(76, 16);
            this.land_LABEL6.TabIndex = 26;
            this.land_LABEL6.Text = "Landscape";
            // 
            // Planning
            // 
            this.Planning.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Planning.FormattingEnabled = true;
            this.Planning.Items.AddRange(new object[] {
            "",
            "Boston",
            "Worcester - 0",
            "Worcester - 1",
            "West Yarmouth",
            "Glastonbury"});
            this.Planning.Location = new System.Drawing.Point(158, 111);
            this.Planning.Name = "Planning";
            this.Planning.Size = new System.Drawing.Size(121, 21);
            this.Planning.TabIndex = 27;
            // 
            // Structural
            // 
            this.Structural.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Structural.FormattingEnabled = true;
            this.Structural.Items.AddRange(new object[] {
            "",
            "Boston",
            "Worcester - 0",
            "Worcester - 1",
            "West Yarmouth",
            "Glastonbury"});
            this.Structural.Location = new System.Drawing.Point(158, 134);
            this.Structural.Name = "Structural";
            this.Structural.Size = new System.Drawing.Size(121, 21);
            this.Structural.TabIndex = 28;
            // 
            // Survey
            // 
            this.Survey.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Survey.FormattingEnabled = true;
            this.Survey.Items.AddRange(new object[] {
            "",
            "Boston",
            "Worcester - 0",
            "Worcester - 1",
            "West Yarmouth",
            "Glastonbury"});
            this.Survey.Location = new System.Drawing.Point(158, 157);
            this.Survey.Name = "Survey";
            this.Survey.Size = new System.Drawing.Size(121, 21);
            this.Survey.TabIndex = 29;
            // 
            // plan_LABEL7
            // 
            this.plan_LABEL7.AutoSize = true;
            this.plan_LABEL7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.plan_LABEL7.Location = new System.Drawing.Point(13, 116);
            this.plan_LABEL7.Name = "plan_LABEL7";
            this.plan_LABEL7.Size = new System.Drawing.Size(60, 16);
            this.plan_LABEL7.TabIndex = 30;
            this.plan_LABEL7.Text = "Planning";
            // 
            // struct_LABEL8
            // 
            this.struct_LABEL8.AutoSize = true;
            this.struct_LABEL8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.struct_LABEL8.Location = new System.Drawing.Point(13, 137);
            this.struct_LABEL8.Name = "struct_LABEL8";
            this.struct_LABEL8.Size = new System.Drawing.Size(63, 16);
            this.struct_LABEL8.TabIndex = 31;
            this.struct_LABEL8.Text = "Structural";
            // 
            // survey_LABEL9
            // 
            this.survey_LABEL9.AutoSize = true;
            this.survey_LABEL9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.survey_LABEL9.Location = new System.Drawing.Point(13, 160);
            this.survey_LABEL9.Name = "survey_LABEL9";
            this.survey_LABEL9.Size = new System.Drawing.Size(50, 16);
            this.survey_LABEL9.TabIndex = 32;
            this.survey_LABEL9.Text = "Survey";
            // 
            // Transportation
            // 
            this.Transportation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Transportation.FormattingEnabled = true;
            this.Transportation.Items.AddRange(new object[] {
            "",
            "Boston",
            "Worcester - 0",
            "Worcester - 1",
            "West Yarmouth",
            "Glastonbury"});
            this.Transportation.Location = new System.Drawing.Point(451, 112);
            this.Transportation.Name = "Transportation";
            this.Transportation.Size = new System.Drawing.Size(121, 21);
            this.Transportation.TabIndex = 33;
            // 
            // zForGIS
            // 
            this.zForGIS.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.zForGIS.FormattingEnabled = true;
            this.zForGIS.Items.AddRange(new object[] {
            "",
            "Boston",
            "Worcester - 0",
            "Worcester - 1",
            "West Yarmouth",
            "Glastonbury"});
            this.zForGIS.Location = new System.Drawing.Point(451, 135);
            this.zForGIS.Name = "zForGIS";
            this.zForGIS.Size = new System.Drawing.Size(121, 21);
            this.zForGIS.TabIndex = 34;
            // 
            // zForSurveyRoot
            // 
            this.zForSurveyRoot.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.zForSurveyRoot.FormattingEnabled = true;
            this.zForSurveyRoot.Items.AddRange(new object[] {
            "",
            "Boston",
            "Worcester - 0",
            "Worcester - 1",
            "West Yarmouth",
            "Glastonbury"});
            this.zForSurveyRoot.Location = new System.Drawing.Point(451, 158);
            this.zForSurveyRoot.Name = "zForSurveyRoot";
            this.zForSurveyRoot.Size = new System.Drawing.Size(121, 21);
            this.zForSurveyRoot.TabIndex = 35;
            // 
            // trans_LABEL10
            // 
            this.trans_LABEL10.AutoSize = true;
            this.trans_LABEL10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trans_LABEL10.Location = new System.Drawing.Point(306, 117);
            this.trans_LABEL10.Name = "trans_LABEL10";
            this.trans_LABEL10.Size = new System.Drawing.Size(95, 16);
            this.trans_LABEL10.TabIndex = 36;
            this.trans_LABEL10.Text = "Transportation";
            // 
            // zGIS_LABEL11
            // 
            this.zGIS_LABEL11.AutoSize = true;
            this.zGIS_LABEL11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zGIS_LABEL11.Location = new System.Drawing.Point(306, 138);
            this.zGIS_LABEL11.Name = "zGIS_LABEL11";
            this.zGIS_LABEL11.Size = new System.Drawing.Size(63, 16);
            this.zGIS_LABEL11.TabIndex = 37;
            this.zGIS_LABEL11.Text = "z-For GIS";
            // 
            // zRootSurvey_LABEL12
            // 
            this.zRootSurvey_LABEL12.AutoSize = true;
            this.zRootSurvey_LABEL12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zRootSurvey_LABEL12.Location = new System.Drawing.Point(306, 161);
            this.zRootSurvey_LABEL12.Name = "zRootSurvey_LABEL12";
            this.zRootSurvey_LABEL12.Size = new System.Drawing.Size(135, 16);
            this.zRootSurvey_LABEL12.TabIndex = 38;
            this.zRootSurvey_LABEL12.Text = "z-For Survey Root Dir";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem,
            this.toolsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(583, 24);
            this.menuStrip1.TabIndex = 39;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // toolsToolStripMenuItem
            // 
            this.toolsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.configurationsToolStripMenuItem,
            this.clearFieldsToolStripMenuItem});
            this.toolsToolStripMenuItem.Name = "toolsToolStripMenuItem";
            this.toolsToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.toolsToolStripMenuItem.Text = "Tools";
            // 
            // clearFieldsToolStripMenuItem
            // 
            this.clearFieldsToolStripMenuItem.Name = "clearFieldsToolStripMenuItem";
            this.clearFieldsToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.clearFieldsToolStripMenuItem.Text = "Clear Fields";
            this.clearFieldsToolStripMenuItem.Click += new System.EventHandler(this.clearFieldsToolStripMenuItem_Click);
            // 
            // FilePathName
            // 
            this.FilePathName.Location = new System.Drawing.Point(15, 239);
            this.FilePathName.Name = "FilePathName";
            this.FilePathName.Size = new System.Drawing.Size(183, 20);
            this.FilePathName.TabIndex = 40;
            // 
            // browse
            // 
            this.browse.Location = new System.Drawing.Point(204, 239);
            this.browse.Name = "browse";
            this.browse.Size = new System.Drawing.Size(75, 23);
            this.browse.TabIndex = 41;
            this.browse.Text = "Browse . . .";
            this.browse.UseVisualStyleBackColor = true;
            this.browse.Click += new System.EventHandler(this.browse_Click_1);
            // 
            // configurationsToolStripMenuItem
            // 
            this.configurationsToolStripMenuItem.Name = "configurationsToolStripMenuItem";
            this.configurationsToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.configurationsToolStripMenuItem.Text = "Configurations";
            this.configurationsToolStripMenuItem.Click += new System.EventHandler(this.configurationsToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.NavajoWhite;
            this.ClientSize = new System.Drawing.Size(583, 280);
            this.Controls.Add(this.browse);
            this.Controls.Add(this.FilePathName);
            this.Controls.Add(this.zRootSurvey_LABEL12);
            this.Controls.Add(this.zGIS_LABEL11);
            this.Controls.Add(this.trans_LABEL10);
            this.Controls.Add(this.zForSurveyRoot);
            this.Controls.Add(this.zForGIS);
            this.Controls.Add(this.Transportation);
            this.Controls.Add(this.GIS);
            this.Controls.Add(this.survey_LABEL9);
            this.Controls.Add(this.proj_num);
            this.Controls.Add(this.struct_LABEL8);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.plan_LABEL7);
            this.Controls.Add(this.create_proj);
            this.Controls.Add(this.Survey);
            this.Controls.Add(this.ProjectControl);
            this.Controls.Add(this.Structural);
            this.Controls.Add(this.CivilEngineering);
            this.Controls.Add(this.Planning);
            this.Controls.Add(this.Enviro);
            this.Controls.Add(this.land_LABEL6);
            this.Controls.Add(this.prj_LABEL1);
            this.Controls.Add(this.haza_LABEL5);
            this.Controls.Add(this.civil_LABEL2);
            this.Controls.Add(this.GIS_LABEL4);
            this.Controls.Add(this.enviro_LABEL3);
            this.Controls.Add(this.Landscape);
            this.Controls.Add(this.HazMaterials);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "BSC Project Creator v.1.10.5.13";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.TextBox proj_num;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button create_proj;
        public System.Windows.Forms.ComboBox ProjectControl;
        public System.Windows.Forms.ComboBox CivilEngineering;
        public System.Windows.Forms.ComboBox Enviro;
        private System.Windows.Forms.Label prj_LABEL1;
        private System.Windows.Forms.Label civil_LABEL2;
        private System.Windows.Forms.Label enviro_LABEL3;
        public System.Windows.Forms.ComboBox GIS;
        public System.Windows.Forms.ComboBox HazMaterials;
        public System.Windows.Forms.ComboBox Landscape;
        private System.Windows.Forms.Label GIS_LABEL4;
        private System.Windows.Forms.Label haza_LABEL5;
        private System.Windows.Forms.Label land_LABEL6;
        public System.Windows.Forms.ComboBox Planning;
        public System.Windows.Forms.ComboBox Structural;
        public System.Windows.Forms.ComboBox Survey;
        private System.Windows.Forms.Label plan_LABEL7;
        private System.Windows.Forms.Label struct_LABEL8;
        private System.Windows.Forms.Label survey_LABEL9;
        public System.Windows.Forms.ComboBox Transportation;
        public System.Windows.Forms.ComboBox zForGIS;
        public System.Windows.Forms.ComboBox zForSurveyRoot;
        private System.Windows.Forms.Label trans_LABEL10;
        private System.Windows.Forms.Label zGIS_LABEL11;
        private System.Windows.Forms.Label zRootSurvey_LABEL12;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.TextBox FilePathName;
        private System.Windows.Forms.Button browse;
        private System.Windows.Forms.ToolStripMenuItem toolsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clearFieldsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem configurationsToolStripMenuItem;
    }
}

