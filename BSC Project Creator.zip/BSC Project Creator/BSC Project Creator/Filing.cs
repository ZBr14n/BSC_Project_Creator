﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.IO;
using BSC_Project_Creator.Properties;

namespace BSC_Project_Creator
{
    class Filing
    {
        private string project_name;

        public Filing() { project_name = ""; }
        public Filing(string prjName)
        {
            project_name = prjName;
        }

        public string GETSETprj_name
        {
            get { return project_name; }
            set { project_name = value; }
        }

        //change combobox values according to configuration page Locations
        public static void chgComboVal(ComboBox combo) {

            string[] storeSettings = new string[] { Settings.Default["L1"].ToString(), Settings.Default["L2"].ToString(), Settings.Default["L3"].ToString(), Settings.Default["L4"].ToString() };

            for (int i = 1; i <= combo.Items.Count; i++)
                combo.Items.RemoveAt(i);

            int k=1;
            for (int j = 0; j < storeSettings.Length; j++)
            {
                combo.Items.Insert(k, storeSettings[j]); k++;
            }
        }

        //if true, method will be used to warn user.
        public bool DirectoryExists(string location, string projectNum, string stuff)
        {
            if (location == Settings.Default["L1"].ToString())
                return Directory.Exists(getUNCpath(Settings.Default["L1"].ToString(), projectNum, stuff));

            else if (location == Settings.Default["L2"].ToString())
                return Directory.Exists(getUNCpath(Settings.Default["L2"].ToString(), projectNum, stuff));

            else if (location == Settings.Default["L3"].ToString())
                return Directory.Exists(getUNCpath(Settings.Default["L3"].ToString(), projectNum, stuff));

            else if (location == Settings.Default["L4"].ToString())
                return Directory.Exists(getUNCpath(Settings.Default["L4"].ToString(), projectNum, stuff));
            
            else
                return false; //if false initialize the process.
        }

        //for temporary use, until the sharefolders are migrated.
        public string PhotoPath(string network_path, string prj_num)
        {
            if (network_path == "Glastonbury")
                return @"\\gzen1\pictures\" + prj_num;
            else if (network_path == "West Yarmouth")
                return @"\\yzen1\pictures\" + prj_num;

            return "";
        }

        //returns the path + prj ID + subfolders
        public string getUNCpath(string network_path, string prj_num, string subfolders)
        {
            if (network_path == Settings.Default["L1"].ToString())
                return @Settings.Default["DirLoc1"] + prj_num + "\\" + subfolders;

            else if (network_path == Settings.Default["L2"].ToString())
                return @Settings.Default["DirLoc2"] + prj_num + "\\" + subfolders;

            else if (network_path == Settings.Default["L3"].ToString())
                return @Settings.Default["DirLoc3"] + prj_num + "\\" + subfolders;

            else if (network_path == Settings.Default["L4"].ToString())
                return @Settings.Default["DirLoc4"] + prj_num + "\\" + subfolders;

            return "";
        }

        //returns the path + proj ID
        public string getUNCpath(string network_path, string prj_num)
        {
            if (network_path == Settings.Default["L1"].ToString())
                return @Settings.Default["DirLoc1"] + "\\" + prj_num;

            else if (network_path == Settings.Default["L2"].ToString())
                return @Settings.Default["DirLoc2"] + "\\" + prj_num;

            else if (network_path == Settings.Default["L3"].ToString())
                return @Settings.Default["DirLoc3"] + "\\" + prj_num;

            else if (network_path == Settings.Default["L4"].ToString())
                return @Settings.Default["DirLoc4"] + "\\" + prj_num;

            else if (network_path == Settings.Default["bosLBL"].ToString())
                return @Settings.Default["bosGIS"] + "\\" + prj_num;

            else if (network_path == Settings.Default["worLBL"].ToString())
                return @Settings.Default["worGIS"] + "\\" + prj_num;

            return "";
        }

        public void getDirectoryInfo(DirectoryInfo theSource, DirectoryInfo theDest, string where,
                                     Filing theProject, string dataDIR)
        {

            Directory.CreateDirectory(theProject.getUNCpath(where, theProject.GETSETprj_name));             //creates main project folder with ID
            Directory.CreateDirectory(theProject.getUNCpath(where, theProject.GETSETprj_name) + "\\" + dataDIR);    //creates subfolders within it

            Filing.CopyFilesRecursively(theSource, theDest);
        }

        //Short and simple code from MSDN that copies all files and folders from one location to another.
        public static void CopyFilesRecursively(DirectoryInfo source, DirectoryInfo target)
        {
            foreach (DirectoryInfo dir in source.GetDirectories())
                CopyFilesRecursively(dir, target.CreateSubdirectory(dir.Name));
            foreach (FileInfo file in source.GetFiles())
                file.CopyTo(Path.Combine(target.FullName, file.Name));
        }
    }
}
