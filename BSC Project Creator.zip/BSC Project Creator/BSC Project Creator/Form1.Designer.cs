﻿namespace BSC_Project_Creator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.zRootSurvey_LABEL12 = new System.Windows.Forms.Label();
            this.zGIS_LABEL11 = new System.Windows.Forms.Label();
            this.trans_LABEL10 = new System.Windows.Forms.Label();
            this.zForSurveyRoot = new System.Windows.Forms.ComboBox();
            this.zForGIS = new System.Windows.Forms.ComboBox();
            this.Transportation = new System.Windows.Forms.ComboBox();
            this.GIS = new System.Windows.Forms.ComboBox();
            this.survey_LABEL9 = new System.Windows.Forms.Label();
            this.proj_num = new System.Windows.Forms.TextBox();
            this.struct_LABEL8 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.plan_LABEL7 = new System.Windows.Forms.Label();
            this.create_proj = new System.Windows.Forms.Button();
            this.Survey = new System.Windows.Forms.ComboBox();
            this.ProjectControl = new System.Windows.Forms.ComboBox();
            this.Structural = new System.Windows.Forms.ComboBox();
            this.CivilEngineering = new System.Windows.Forms.ComboBox();
            this.Planning = new System.Windows.Forms.ComboBox();
            this.Enviro = new System.Windows.Forms.ComboBox();
            this.land_LABEL6 = new System.Windows.Forms.Label();
            this.prj_LABEL1 = new System.Windows.Forms.Label();
            this.haza_LABEL5 = new System.Windows.Forms.Label();
            this.civil_LABEL2 = new System.Windows.Forms.Label();
            this.GIS_LABEL4 = new System.Windows.Forms.Label();
            this.enviro_LABEL3 = new System.Windows.Forms.Label();
            this.Landscape = new System.Windows.Forms.ComboBox();
            this.HazMaterials = new System.Windows.Forms.ComboBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.configurationsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // zRootSurvey_LABEL12
            // 
            this.zRootSurvey_LABEL12.AutoSize = true;
            this.zRootSurvey_LABEL12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zRootSurvey_LABEL12.ForeColor = System.Drawing.Color.Black;
            this.zRootSurvey_LABEL12.Location = new System.Drawing.Point(290, 238);
            this.zRootSurvey_LABEL12.Name = "zRootSurvey_LABEL12";
            this.zRootSurvey_LABEL12.Size = new System.Drawing.Size(152, 16);
            this.zRootSurvey_LABEL12.TabIndex = 65;
            this.zRootSurvey_LABEL12.Text = "_For Survey Root Dir";
            // 
            // zGIS_LABEL11
            // 
            this.zGIS_LABEL11.AutoSize = true;
            this.zGIS_LABEL11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zGIS_LABEL11.ForeColor = System.Drawing.Color.Black;
            this.zGIS_LABEL11.Location = new System.Drawing.Point(290, 215);
            this.zGIS_LABEL11.Name = "zGIS_LABEL11";
            this.zGIS_LABEL11.Size = new System.Drawing.Size(109, 16);
            this.zGIS_LABEL11.TabIndex = 64;
            this.zGIS_LABEL11.Text = "_For GIS Drive";
            // 
            // trans_LABEL10
            // 
            this.trans_LABEL10.AutoSize = true;
            this.trans_LABEL10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trans_LABEL10.ForeColor = System.Drawing.Color.Black;
            this.trans_LABEL10.Location = new System.Drawing.Point(290, 194);
            this.trans_LABEL10.Name = "trans_LABEL10";
            this.trans_LABEL10.Size = new System.Drawing.Size(109, 16);
            this.trans_LABEL10.TabIndex = 63;
            this.trans_LABEL10.Text = "Transportation";
            // 
            // zForSurveyRoot
            // 
            this.zForSurveyRoot.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.zForSurveyRoot.FormattingEnabled = true;
            this.zForSurveyRoot.Items.AddRange(new object[] {
            "",
            "a"});
            this.zForSurveyRoot.Location = new System.Drawing.Point(448, 235);
            this.zForSurveyRoot.Name = "zForSurveyRoot";
            this.zForSurveyRoot.Size = new System.Drawing.Size(121, 21);
            this.zForSurveyRoot.TabIndex = 62;
            this.zForSurveyRoot.TabStop = false;
            // 
            // zForGIS
            // 
            this.zForGIS.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.zForGIS.FormattingEnabled = true;
            this.zForGIS.Items.AddRange(new object[] {
            "",
            "a"});
            this.zForGIS.Location = new System.Drawing.Point(448, 212);
            this.zForGIS.Name = "zForGIS";
            this.zForGIS.Size = new System.Drawing.Size(121, 21);
            this.zForGIS.TabIndex = 61;
            this.zForGIS.TabStop = false;
            // 
            // Transportation
            // 
            this.Transportation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Transportation.FormattingEnabled = true;
            this.Transportation.Items.AddRange(new object[] {
            "",
            "a"});
            this.Transportation.Location = new System.Drawing.Point(448, 189);
            this.Transportation.Name = "Transportation";
            this.Transportation.Size = new System.Drawing.Size(121, 21);
            this.Transportation.TabIndex = 60;
            this.Transportation.TabStop = false;
            // 
            // GIS
            // 
            this.GIS.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.GIS.FormattingEnabled = true;
            this.GIS.Items.AddRange(new object[] {
            "",
            "a"});
            this.GIS.Location = new System.Drawing.Point(448, 93);
            this.GIS.Name = "GIS";
            this.GIS.Size = new System.Drawing.Size(121, 21);
            this.GIS.TabIndex = 48;
            this.GIS.TabStop = false;
            // 
            // survey_LABEL9
            // 
            this.survey_LABEL9.AutoSize = true;
            this.survey_LABEL9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.survey_LABEL9.ForeColor = System.Drawing.Color.Black;
            this.survey_LABEL9.Location = new System.Drawing.Point(27, 237);
            this.survey_LABEL9.Name = "survey_LABEL9";
            this.survey_LABEL9.Size = new System.Drawing.Size(56, 16);
            this.survey_LABEL9.TabIndex = 59;
            this.survey_LABEL9.Text = "Survey";
            // 
            // proj_num
            // 
            this.proj_num.Location = new System.Drawing.Point(271, 47);
            this.proj_num.Name = "proj_num";
            this.proj_num.Size = new System.Drawing.Size(121, 20);
            this.proj_num.TabIndex = 39;
            // 
            // struct_LABEL8
            // 
            this.struct_LABEL8.AutoSize = true;
            this.struct_LABEL8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.struct_LABEL8.ForeColor = System.Drawing.Color.Black;
            this.struct_LABEL8.Location = new System.Drawing.Point(27, 214);
            this.struct_LABEL8.Name = "struct_LABEL8";
            this.struct_LABEL8.Size = new System.Drawing.Size(73, 16);
            this.struct_LABEL8.TabIndex = 58;
            this.struct_LABEL8.Text = "Structural";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(147, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(115, 16);
            this.label1.TabIndex = 40;
            this.label1.Text = "Project Number";
            // 
            // plan_LABEL7
            // 
            this.plan_LABEL7.AutoSize = true;
            this.plan_LABEL7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.plan_LABEL7.ForeColor = System.Drawing.Color.Black;
            this.plan_LABEL7.Location = new System.Drawing.Point(27, 193);
            this.plan_LABEL7.Name = "plan_LABEL7";
            this.plan_LABEL7.Size = new System.Drawing.Size(68, 16);
            this.plan_LABEL7.TabIndex = 57;
            this.plan_LABEL7.Text = "Planning";
            // 
            // create_proj
            // 
            this.create_proj.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.create_proj.Location = new System.Drawing.Point(149, 284);
            this.create_proj.Name = "create_proj";
            this.create_proj.Size = new System.Drawing.Size(243, 59);
            this.create_proj.TabIndex = 41;
            this.create_proj.Text = "Create Project";
            this.create_proj.UseVisualStyleBackColor = true;
            this.create_proj.Click += new System.EventHandler(this.create_proj_Click);
            // 
            // Survey
            // 
            this.Survey.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Survey.FormattingEnabled = true;
            this.Survey.Items.AddRange(new object[] {
            "",
            "a"});
            this.Survey.Location = new System.Drawing.Point(144, 234);
            this.Survey.Name = "Survey";
            this.Survey.Size = new System.Drawing.Size(121, 21);
            this.Survey.TabIndex = 56;
            this.Survey.TabStop = false;
            // 
            // ProjectControl
            // 
            this.ProjectControl.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ProjectControl.FormattingEnabled = true;
            this.ProjectControl.Items.AddRange(new object[] {
            "",
            "a"});
            this.ProjectControl.Location = new System.Drawing.Point(144, 90);
            this.ProjectControl.Name = "ProjectControl";
            this.ProjectControl.Size = new System.Drawing.Size(121, 21);
            this.ProjectControl.TabIndex = 42;
            this.ProjectControl.TabStop = false;
            // 
            // Structural
            // 
            this.Structural.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Structural.FormattingEnabled = true;
            this.Structural.Items.AddRange(new object[] {
            "",
            "a"});
            this.Structural.Location = new System.Drawing.Point(144, 211);
            this.Structural.Name = "Structural";
            this.Structural.Size = new System.Drawing.Size(121, 21);
            this.Structural.TabIndex = 55;
            this.Structural.TabStop = false;
            // 
            // CivilEngineering
            // 
            this.CivilEngineering.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CivilEngineering.FormattingEnabled = true;
            this.CivilEngineering.Items.AddRange(new object[] {
            "",
            "a"});
            this.CivilEngineering.Location = new System.Drawing.Point(144, 113);
            this.CivilEngineering.Name = "CivilEngineering";
            this.CivilEngineering.Size = new System.Drawing.Size(121, 21);
            this.CivilEngineering.TabIndex = 43;
            this.CivilEngineering.TabStop = false;
            // 
            // Planning
            // 
            this.Planning.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Planning.FormattingEnabled = true;
            this.Planning.Items.AddRange(new object[] {
            "",
            "a"});
            this.Planning.Location = new System.Drawing.Point(144, 188);
            this.Planning.Name = "Planning";
            this.Planning.Size = new System.Drawing.Size(121, 21);
            this.Planning.TabIndex = 54;
            this.Planning.TabStop = false;
            // 
            // Enviro
            // 
            this.Enviro.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Enviro.FormattingEnabled = true;
            this.Enviro.Items.AddRange(new object[] {
            "",
            "a"});
            this.Enviro.Location = new System.Drawing.Point(144, 136);
            this.Enviro.Name = "Enviro";
            this.Enviro.Size = new System.Drawing.Size(121, 21);
            this.Enviro.TabIndex = 44;
            this.Enviro.TabStop = false;
            // 
            // land_LABEL6
            // 
            this.land_LABEL6.AutoSize = true;
            this.land_LABEL6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.land_LABEL6.ForeColor = System.Drawing.Color.Black;
            this.land_LABEL6.Location = new System.Drawing.Point(290, 142);
            this.land_LABEL6.Name = "land_LABEL6";
            this.land_LABEL6.Size = new System.Drawing.Size(85, 16);
            this.land_LABEL6.TabIndex = 53;
            this.land_LABEL6.Text = "Landscape";
            // 
            // prj_LABEL1
            // 
            this.prj_LABEL1.AutoSize = true;
            this.prj_LABEL1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prj_LABEL1.ForeColor = System.Drawing.Color.Black;
            this.prj_LABEL1.Location = new System.Drawing.Point(27, 95);
            this.prj_LABEL1.Name = "prj_LABEL1";
            this.prj_LABEL1.Size = new System.Drawing.Size(110, 16);
            this.prj_LABEL1.TabIndex = 45;
            this.prj_LABEL1.Text = "Project Control";
            // 
            // haza_LABEL5
            // 
            this.haza_LABEL5.AutoSize = true;
            this.haza_LABEL5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.haza_LABEL5.ForeColor = System.Drawing.Color.Black;
            this.haza_LABEL5.Location = new System.Drawing.Point(290, 119);
            this.haza_LABEL5.Name = "haza_LABEL5";
            this.haza_LABEL5.Size = new System.Drawing.Size(151, 16);
            this.haza_LABEL5.TabIndex = 52;
            this.haza_LABEL5.Text = "Hazardous Materials";
            // 
            // civil_LABEL2
            // 
            this.civil_LABEL2.AutoSize = true;
            this.civil_LABEL2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.civil_LABEL2.ForeColor = System.Drawing.Color.Black;
            this.civil_LABEL2.Location = new System.Drawing.Point(27, 116);
            this.civil_LABEL2.Name = "civil_LABEL2";
            this.civil_LABEL2.Size = new System.Drawing.Size(38, 16);
            this.civil_LABEL2.TabIndex = 46;
            this.civil_LABEL2.Text = "Civil";
            // 
            // GIS_LABEL4
            // 
            this.GIS_LABEL4.AutoSize = true;
            this.GIS_LABEL4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GIS_LABEL4.ForeColor = System.Drawing.Color.Black;
            this.GIS_LABEL4.Location = new System.Drawing.Point(290, 98);
            this.GIS_LABEL4.Name = "GIS_LABEL4";
            this.GIS_LABEL4.Size = new System.Drawing.Size(33, 16);
            this.GIS_LABEL4.TabIndex = 51;
            this.GIS_LABEL4.Text = "GIS";
            // 
            // enviro_LABEL3
            // 
            this.enviro_LABEL3.AutoSize = true;
            this.enviro_LABEL3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.enviro_LABEL3.ForeColor = System.Drawing.Color.Black;
            this.enviro_LABEL3.Location = new System.Drawing.Point(27, 139);
            this.enviro_LABEL3.Name = "enviro_LABEL3";
            this.enviro_LABEL3.Size = new System.Drawing.Size(106, 16);
            this.enviro_LABEL3.TabIndex = 47;
            this.enviro_LABEL3.Text = "Environmental";
            // 
            // Landscape
            // 
            this.Landscape.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Landscape.FormattingEnabled = true;
            this.Landscape.Items.AddRange(new object[] {
            "",
            "a"});
            this.Landscape.Location = new System.Drawing.Point(448, 139);
            this.Landscape.Name = "Landscape";
            this.Landscape.Size = new System.Drawing.Size(121, 21);
            this.Landscape.TabIndex = 50;
            this.Landscape.TabStop = false;
            // 
            // HazMaterials
            // 
            this.HazMaterials.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.HazMaterials.FormattingEnabled = true;
            this.HazMaterials.Items.AddRange(new object[] {
            "",
            "a"});
            this.HazMaterials.Location = new System.Drawing.Point(448, 116);
            this.HazMaterials.Name = "HazMaterials";
            this.HazMaterials.Size = new System.Drawing.Size(121, 21);
            this.HazMaterials.TabIndex = 49;
            this.HazMaterials.TabStop = false;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem,
            this.configurationsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(600, 24);
            this.menuStrip1.TabIndex = 66;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // configurationsToolStripMenuItem
            // 
            this.configurationsToolStripMenuItem.Name = "configurationsToolStripMenuItem";
            this.configurationsToolStripMenuItem.Size = new System.Drawing.Size(98, 20);
            this.configurationsToolStripMenuItem.Text = "Configurations";
            this.configurationsToolStripMenuItem.Click += new System.EventHandler(this.configurationsToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.create_proj;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.BlanchedAlmond;
            this.ClientSize = new System.Drawing.Size(600, 363);
            this.Controls.Add(this.zRootSurvey_LABEL12);
            this.Controls.Add(this.zGIS_LABEL11);
            this.Controls.Add(this.trans_LABEL10);
            this.Controls.Add(this.zForSurveyRoot);
            this.Controls.Add(this.zForGIS);
            this.Controls.Add(this.Transportation);
            this.Controls.Add(this.GIS);
            this.Controls.Add(this.survey_LABEL9);
            this.Controls.Add(this.proj_num);
            this.Controls.Add(this.struct_LABEL8);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.plan_LABEL7);
            this.Controls.Add(this.create_proj);
            this.Controls.Add(this.Survey);
            this.Controls.Add(this.ProjectControl);
            this.Controls.Add(this.Structural);
            this.Controls.Add(this.CivilEngineering);
            this.Controls.Add(this.Planning);
            this.Controls.Add(this.Enviro);
            this.Controls.Add(this.land_LABEL6);
            this.Controls.Add(this.prj_LABEL1);
            this.Controls.Add(this.haza_LABEL5);
            this.Controls.Add(this.civil_LABEL2);
            this.Controls.Add(this.GIS_LABEL4);
            this.Controls.Add(this.enviro_LABEL3);
            this.Controls.Add(this.Landscape);
            this.Controls.Add(this.HazMaterials);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "BSC Project Creator v. 12.10.13";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label zRootSurvey_LABEL12;
        private System.Windows.Forms.Label zGIS_LABEL11;
        private System.Windows.Forms.Label trans_LABEL10;
        public System.Windows.Forms.ComboBox zForSurveyRoot;
        public System.Windows.Forms.ComboBox zForGIS;
        public System.Windows.Forms.ComboBox Transportation;
        public System.Windows.Forms.ComboBox GIS;
        private System.Windows.Forms.Label survey_LABEL9;
        private System.Windows.Forms.TextBox proj_num;
        private System.Windows.Forms.Label struct_LABEL8;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label plan_LABEL7;
        private System.Windows.Forms.Button create_proj;
        public System.Windows.Forms.ComboBox Survey;
        public System.Windows.Forms.ComboBox ProjectControl;
        public System.Windows.Forms.ComboBox Structural;
        public System.Windows.Forms.ComboBox CivilEngineering;
        public System.Windows.Forms.ComboBox Planning;
        public System.Windows.Forms.ComboBox Enviro;
        private System.Windows.Forms.Label land_LABEL6;
        private System.Windows.Forms.Label prj_LABEL1;
        private System.Windows.Forms.Label haza_LABEL5;
        private System.Windows.Forms.Label civil_LABEL2;
        private System.Windows.Forms.Label GIS_LABEL4;
        private System.Windows.Forms.Label enviro_LABEL3;
        public System.Windows.Forms.ComboBox Landscape;
        public System.Windows.Forms.ComboBox HazMaterials;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem configurationsToolStripMenuItem;
    }
}

