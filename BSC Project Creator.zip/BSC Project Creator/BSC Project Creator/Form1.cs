﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using BSC_Project_Creator.Properties;

namespace BSC_Project_Creator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void configurationsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.ShowDialog();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Filing.chgComboVal(ProjectControl); Filing.chgComboVal(CivilEngineering); Filing.chgComboVal(Enviro);
            Filing.chgComboVal(GIS); Filing.chgComboVal(HazMaterials); Filing.chgComboVal(Landscape);
            Filing.chgComboVal(Planning); Filing.chgComboVal(Structural); Filing.chgComboVal(Survey);
            Filing.chgComboVal(Transportation); Filing.chgComboVal(zForGIS); Filing.chgComboVal(zForSurveyRoot);
        }

        private void create_proj_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            Filing theProject = new Filing(proj_num.Text);
         
            string[] storeDataLoc = new string[] { ProjectControl.Text, CivilEngineering.Text, Enviro.Text,GIS.Text,HazMaterials.Text,
                                                   Landscape.Text,Planning.Text,Structural.Text,Survey.Text,Transportation.Text,zForGIS.Text,
                                                   zForSurveyRoot.Text };

            string[] storeLABELS = new string[] { prj_LABEL1.Text, civil_LABEL2.Text, enviro_LABEL3.Text,GIS_LABEL4.Text,haza_LABEL5.Text,
                                                  land_LABEL6.Text,plan_LABEL7.Text,struct_LABEL8.Text,survey_LABEL9.Text,trans_LABEL10.Text,
                                                  zGIS_LABEL11.Text,zRootSurvey_LABEL12.Text };
            
            DialogResult ans = MessageBox.Show("Are you sure you want to continue?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (proj_num.Text == "")
            {
                MessageBox.Show("The field is empty. Please enter the Project Number.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else 
            {
                for (int i = 0, j = 0; i < storeDataLoc.Length && j < storeLABELS.Length; i++, j++)
                {
                    if (theProject.DirectoryExists(storeDataLoc[i], theProject.GETSETprj_name, storeLABELS[j]) == true)
                    {
                        MessageBox.Show("There is already an existing directory; unable to add the same Project folder(s) to the directory. However, there are new Project folder(s) that have been added to the directory. No files or folders have been deleted or overwritten.",
                                        "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        break;
                    }
                }

                if (ans == DialogResult.Yes)
                {
                    for (int i = 0, j = 0; i < storeDataLoc.Length && j < storeLABELS.Length; i++, j++)
                    {
                        if (storeDataLoc[i].Contains(Settings.Default["L1"].ToString())) //looks for all needed locations
                        {
                            if (zForGIS.Text != "") //if zforGIS.text is selected along with other folders, direct these folders to differ destinations.
                            {
                                DirectoryInfo theSource = new DirectoryInfo(@Settings.Default["prjFolders"].ToString() + "\\" + storeLABELS[j]);       // \\bscbos\bos\Projects-BOS\4645603\
                                DirectoryInfo theDest = new DirectoryInfo(@Settings.Default["DirLoc1"] + "\\" + theProject.GETSETprj_name + "\\" + storeLABELS[j]);
                                theProject.getDirectoryInfo(theSource, theDest, Settings.Default["L1"].ToString(), theProject, storeLABELS[j]);
                                Directory.CreateDirectory(@Settings.Default["DirLoc1"].ToString() + "\\" + theProject.GETSETprj_name + "\\" + "Photos"); 
                                                                       
                                if(!Directory.Exists(@Settings.Default["bosGIS"].ToString() + "\\" + theProject.GETSETprj_name + "\\" + zGIS_LABEL11.Text)) //we want GIS folder here.
                                {
                                    DirectoryInfo source2 = new DirectoryInfo(@Settings.Default["prjFolders"].ToString() + "\\" + zGIS_LABEL11.Text);
                                    Directory.CreateDirectory(@Settings.Default["bosGIS"].ToString() + "\\" + theProject.GETSETprj_name);
                                    DirectoryInfo dest2 = new DirectoryInfo(@Settings.Default["bosGIS"].ToString() + "\\" + theProject.GETSETprj_name + "\\" + zGIS_LABEL11.Text);
                                    Filing.CopyFilesRecursively(source2, dest2);
                                    Directory.CreateDirectory(@Settings.Default["bosGIS"].ToString() + "\\" + theProject.GETSETprj_name + "\\" + "Photos");
                                }
                                
                            }
                            else //if zForGIS not selected, then do regular copying.
                            {
                                DirectoryInfo theSource = new DirectoryInfo(@Settings.Default["prjFolders"].ToString() + "\\" + storeLABELS[j]);       // \\bscbos\bos\Projects-BOS\4645603\
                                DirectoryInfo theDest = new DirectoryInfo(@Settings.Default["DirLoc1"] + "\\" + theProject.GETSETprj_name + "\\" + storeLABELS[j]);
                                theProject.getDirectoryInfo(theSource, theDest, Settings.Default["L1"].ToString(), theProject, storeLABELS[j]);
                                Directory.CreateDirectory(@Settings.Default["DirLoc1"].ToString() + "\\" + theProject.GETSETprj_name + "\\" + "Photos");
                            } 

                        }
                        else if (storeDataLoc[i].Contains(Settings.Default["L2"].ToString()))
                        {
                            if (zForGIS.Text != "") //if zforGIS.text is selected along with other folders, direct these folders to differ destinations.
                            {
                                DirectoryInfo theSource = new DirectoryInfo(@Settings.Default["prjFolders"].ToString() + "\\" + storeLABELS[j]);       // \\bscbos\bos\Projects-BOS\4645603\
                                DirectoryInfo theDest = new DirectoryInfo(@Settings.Default["DirLoc2"] + "\\" + theProject.GETSETprj_name + "\\" + storeLABELS[j]);
                                theProject.getDirectoryInfo(theSource, theDest, Settings.Default["L2"].ToString(), theProject, storeLABELS[j]);
                                Directory.CreateDirectory(@Settings.Default["DirLoc2"].ToString() + "\\" + theProject.GETSETprj_name + "\\" + "Photos");
                               
                                if (!Directory.Exists(@Settings.Default["worGIS"].ToString() + "\\" + theProject.GETSETprj_name + "\\" + zGIS_LABEL11.Text)) //we want GIS folder here.
                                {
                                    DirectoryInfo source2 = new DirectoryInfo(@Settings.Default["prjFolders"].ToString() + "\\" + zGIS_LABEL11.Text);
                                    Directory.CreateDirectory(@Settings.Default["worGIS"].ToString() + "\\" + theProject.GETSETprj_name);
                                    DirectoryInfo dest2 = new DirectoryInfo(@Settings.Default["worGIS"].ToString() + "\\" + theProject.GETSETprj_name + "\\" + zGIS_LABEL11.Text);
                                    Filing.CopyFilesRecursively(source2, dest2);
                                    Directory.CreateDirectory(@Settings.Default["worGIS"].ToString() + "\\" + theProject.GETSETprj_name + "\\" + "Photos");                             
                                }

                            }
                            else //if zForGIS not selected, then do regular copying.
                            {
                                DirectoryInfo theSource = new DirectoryInfo(@Settings.Default["prjFolders"].ToString() + "\\" + storeLABELS[j]);       // \\bscbos\bos\Projects-BOS\4645603\
                                DirectoryInfo theDest = new DirectoryInfo(@Settings.Default["DirLoc2"] + "\\" + theProject.GETSETprj_name + "\\" + storeLABELS[j]);
                                theProject.getDirectoryInfo(theSource, theDest, Settings.Default["L2"].ToString(), theProject, storeLABELS[j]);
                                Directory.CreateDirectory(@Settings.Default["DirLoc2"].ToString() + "\\" + theProject.GETSETprj_name + "\\" + "Photos");
                            }

                        }
                        else if (storeDataLoc[i].Contains(Settings.Default["L3"].ToString()))
                        {
                            DirectoryInfo theSource = new DirectoryInfo(@Settings.Default["prjFolders"].ToString() + "\\" + storeLABELS[j]);
                            DirectoryInfo theDest = new DirectoryInfo(@Settings.Default["DirLoc3"].ToString() + "\\" + theProject.GETSETprj_name + "\\" + storeLABELS[j]);
                            theProject.getDirectoryInfo(theSource, theDest, "Glastonbury", theProject, storeLABELS[j]);

                            Directory.CreateDirectory(theProject.PhotoPath("Glastonbury", theProject.GETSETprj_name));
                            Directory.CreateDirectory(theProject.PhotoPath("Glastonbury", theProject.GETSETprj_name) + "\\" + "Photos");            
                        }
                        else if (storeDataLoc[i].Contains(Settings.Default["L4"].ToString()))
                        {
                            DirectoryInfo theSource = new DirectoryInfo(@Settings.Default["prjFolders"].ToString() + "\\" + storeLABELS[j]);
                            DirectoryInfo theDest = new DirectoryInfo(@Settings.Default["DirLoc4"] + theProject.GETSETprj_name + "\\" + storeLABELS[j]);
                            theProject.getDirectoryInfo(theSource, theDest, "West Yarmouth", theProject, storeLABELS[j]);

                            Directory.CreateDirectory(theProject.PhotoPath("West Yarmouth", theProject.GETSETprj_name));
                            Directory.CreateDirectory(theProject.PhotoPath("West Yarmouth", theProject.GETSETprj_name) + "\\" + "Photos");
                        }                            
                    }

                    if(Directory.Exists(@Settings.Default["DirLoc1"].ToString() + "\\" + theProject.GETSETprj_name + "\\" + zGIS_LABEL11.Text))
                         Directory.Delete(@Settings.Default["DirLoc1"].ToString() + "\\" + theProject.GETSETprj_name + "\\" + zGIS_LABEL11.Text, true);  //we don't want GIS folder on this path, delete it after copying all the other files.  
                   
                    else if (Directory.Exists(@Settings.Default["DirLoc2"].ToString() + "\\" + theProject.GETSETprj_name + "\\" + zGIS_LABEL11.Text))
                        Directory.Delete(@Settings.Default["DirLoc2"].ToString() + "\\" + theProject.GETSETprj_name + "\\" + zGIS_LABEL11.Text, true);  

                               
                    //takes the user to the created folder without opening too many file explorers.
                    IEnumerable<string> distinctDataLoc = storeDataLoc.Distinct();
                    foreach (string distinctLocations in distinctDataLoc)
                    {
                        if (distinctLocations != "") //checks for non-empty values from the combobox
                        {
                            if (distinctLocations.Contains(Settings.Default["L1"].ToString()))
                            {
                                Process.Start("explorer.exe", "/select," + @Settings.Default["DirLoc1"].ToString() + "\\" + theProject.GETSETprj_name);
                                
                                if (Directory.Exists(@Settings.Default["bosGIS"].ToString() + "\\" + theProject.GETSETprj_name))
                                     Process.Start("explorer.exe", "/select," + @Settings.Default["bosGIS"].ToString() + "\\" + theProject.GETSETprj_name);                                
                            }
                            else if (distinctLocations.Contains(Settings.Default["L2"].ToString())) 
                            {
                                Process.Start("explorer.exe", "/select," + @Settings.Default["DirLoc2"].ToString() + "\\" + theProject.GETSETprj_name);

                                if (Directory.Exists(@Settings.Default["worGIS"].ToString() + "\\" + theProject.GETSETprj_name))
                                     Process.Start("explorer.exe", "/select," + @Settings.Default["worGIS"].ToString() + "\\" + theProject.GETSETprj_name);
                            }
                            else if(distinctLocations.Contains(Settings.Default["L3"].ToString()))
                            {
                                Process.Start("explorer.exe", @"/select," + @Settings.Default["DirLoc3"].ToString() + "\\" + theProject.GETSETprj_name);
                            }
                            else if(distinctLocations.Contains(Settings.Default["L4]"].ToString()))
                            {
                                Process.Start("explorer.exe", @"/select," + @Settings.Default["DirLoc4"].ToString() + "\\" + theProject.GETSETprj_name);
                            }   
                        }
                    } 
                }
                else { }
            }
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            About about = new About();
            about.ShowDialog();
        }
    }
}
