﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BSC_Project_Creator.Properties;

namespace BSC_Project_Creator
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            specialFolder.Text = Settings.Default["prjFolders"].ToString();
            textBox1.Text = Settings.Default["L1"].ToString(); textBox2.Text = Settings.Default["DirLoc1"].ToString();
            textBox4.Text = Settings.Default["L2"].ToString(); textBox3.Text = Settings.Default["DirLoc2"].ToString();
            textBox6.Text = Settings.Default["L3"].ToString(); textBox5.Text = Settings.Default["DirLoc3"].ToString();
            textBox8.Text = Settings.Default["L4"].ToString(); textBox7.Text = Settings.Default["DirLoc4"].ToString();

            textBox10.Text = Settings.Default["bosLBL"].ToString(); textBox9.Text = Settings.Default["bosGIS"].ToString();
            textBox12.Text = Settings.Default["worLBL"].ToString(); textBox11.Text = Settings.Default["worGIS"].ToString();
            textBox1.SelectionStart = textBox1.TextLength;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Settings.Default["prjFolders"] = specialFolder.Text; 
            Settings.Default["L1"] = textBox1.Text; Settings.Default["DirLoc1"] = textBox2.Text;
            Settings.Default["L2"] = textBox4.Text; Settings.Default["DirLoc2"] = textBox3.Text;
            Settings.Default["L3"] = textBox6.Text; Settings.Default["DirLoc3"] = textBox5.Text;
            Settings.Default["L4"] = textBox8.Text; Settings.Default["DirLoc4"] = textBox7.Text;

            Settings.Default["bosLBL"] = textBox10.Text; Settings.Default["bosGIS"] = textBox9.Text;
            Settings.Default["worLBL"] = textBox12.Text; Settings.Default["worGIS"] = textBox11.Text;
            Settings.Default.Save();
            this.Close(); Application.Restart();
        }

        private void enterProjectFoldersToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void defaultSettingsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            specialFolder.Text = @"\\bscbos\bos\IT\Standard Project Folders";
            textBox1.Text = "Boston"; textBox2.Text = @"\\bscbos\bos\Projects-BOS";
            textBox4.Text = "Worcester"; textBox3.Text = @"\\bscbos\wor\Projects-WOR";
            textBox6.Text = "Glastonbury"; textBox5.Text = @"\\lynx\PRJ0\prj";
            textBox8.Text = "West Yarmouth"; textBox7.Text = @"\\dorado\PRJ0\prj";

            textBox10.Text = "BOS GIS"; textBox9.Text = @"\\bos01-dfs\GIS-BOS\GISPrj";
            textBox12.Text = "WOR GIS"; textBox11.Text = @"\\wor01-dfs\GIS-wor\GISPrj";
        }

        private void clearSettingsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            specialFolder.Text = "";
            textBox1.Text = ""; textBox2.Text = "";
            textBox4.Text = ""; textBox3.Text = "";
            textBox6.Text = ""; textBox5.Text = "";
            textBox8.Text = ""; textBox7.Text = "";

            textBox10.Text = ""; textBox9.Text = "";
            textBox12.Text = ""; textBox11.Text = "";
        }
    }
}
